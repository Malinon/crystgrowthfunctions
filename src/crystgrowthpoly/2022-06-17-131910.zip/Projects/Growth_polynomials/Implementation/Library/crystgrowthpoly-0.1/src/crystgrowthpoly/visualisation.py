from crystgrowthpoly.private import *

def get_k_cells(tes, k):
    if k == 0:
        return tes.polygon.points
    if k == 1:
        return tes.polygon.edges
    if k == 2:
        return tes.polygon.faces


class OpenRectangle:
    def __init__(self, lower_left_corner, higher_right_corner):
        self.higher_right_corner = higher_right_corner
        self.lower_left_corner = lower_left_corner
        self.cartesian_corners = None
    def get_area(self):
        return (abs(self.higher_right_corner[0] - self.lower_left_corner[0]) *
        abs(self.higher_right_corner[1] - self.lower_left_corner[1]))
    def get_point_from_interior(self):
        return ((self.higher_right_corner[0]+self.lower_left_corner[0])/2, (self.lower_left_corner[1]+self.higher_right_corner[1])/2 )
    def set_growth_function(self, tes, symmetric_frame):
        self.growth_f = tes.get_growth_polynomials_parallelogram(1,1,self.get_point_from_interior(), symmetric_frame)
    def set_charactetristic(self, tes, symmetric_frame):
        x0 = self.get_point_from_interior()
        if symmetric_frame:
            args = ((1,1), (2,2), (3,3))
        else:
            args = ((1,1), (1,2), (2,1), (2,2))
        self.characteristic = tuple( tuple(get_k_cells_num_parallelogram(arg[0], arg[1], get_k_cells(tes, i), tes.v1, tes.v2, i, x0, 1, 1, tes.v1, tes.v2)   for arg in args)     for i in range(3))
    def get_charactetristic(self):
        return self.characteristic
    def contains_ponts(self, point):
        if self.lower_left_corner[0] < point[0] and self.lower_left_corner[1] < point[1]:
            if self.higher_right_corner[0] > point[0] and self.higher_right_corner[1] > point[1]:
                return True
        return False
    def describe(self, v1, v2):
        p2 = vector((self.higher_right_corner[0], self.lower_left_corner[1]))
        p4 = vector((self.lower_left_corner[0], self.higher_right_corner[1]))
        print("Parallelogram ", (self.lower_left_corner, p2, self.higher_right_corner, p4))
    def to_graphic_polygon(self, v1, v2, color, translation=(0,0)):
        if self.cartesian_corners == None:
            p2 = vector((self.higher_right_corner[0], self.lower_left_corner[1]))
            p4 = vector((self.lower_left_corner[0], self.higher_right_corner[1]))
            inv_mat = column_matrix((v1,v2))
            real_p1 = inv_mat * vector(self.lower_left_corner)
            real_p2 = inv_mat * p2
            real_p3 = inv_mat * vector(self.higher_right_corner)
            real_p4 = inv_mat * p4
            self.cartesian_corners = (real_p1, real_p2, real_p3, real_p4)
        return polygon((corner + vector(translation)  for corner in self.cartesian_corners), color=color)
    def get_random_point(self):
        # TODO: If more sophisticated version will be implemented change this
        return (Rational(uniform(0, 1)),Rational(uniform(0, 1)))
    def get_edges(self):
        return ((self.lower_left_corner, (self.higher_right_corner[0] ,self.lower_left_corner[1])),
        ((self.higher_right_corner[0] ,self.lower_left_corner[1]), self.higher_right_corner),
        ((self.lower_left_corner[0], self.higher_right_corner[1]), self.higher_right_corner ),
         (self.lower_left_corner, (self.lower_left_corner[0], self.higher_right_corner[1])))

class OpenLine:
    def __init__(self, start, end):
        self.start = start
        self.end = end
        self.cartesian_endpoints = None
    def plot(self, v1, v2, color, translation=(0,0)):
        if self.cartesian_endpoints == None:
            mat = matrix((v1, v2))
            real_start = vector(self.start)  * mat
            real_end = vector(self.end)  * mat
            self.cartesian_endpoints = (real_start, real_end)
        return line((self.cartesian_endpoints[0] + vector(translation), self.cartesian_endpoints[1] + vector(translation)), color=color)
    def set_charactetristic(self, tes, symmetric_frame):
        x0 = self.get_point_from_interior()
        if symmetric_frame:
            args = ((1,1), (2,2), (3,3))
        else:
            args = ((1,1), (1,2), (2,1), (2,2))
        self.characteristic = tuple( tuple(get_k_cells_num_parallelogram(arg[0], arg[1], get_k_cells(tes, i), tes.v1, tes.v2, i, x0, 1, 1, tes.v1, tes.v2)   for arg in args)     for i in range(3))
    def get_charactetristic(self):
        return self.characteristic
    def get_point_from_interior(self):
        return ((self.start[0] + self.end[0]) / 2, (self.start[1] + self.end[1]) / 2)
    def set_growth_function(self, tes, symmetric_frame):
        self.growth_f = tes.get_growth_polynomials_parallelogram(1,1,self.get_point_from_interior(), symmetric_frame)
    def describe(self, v1, v2):
        print("Line ", (self.start, self.end))

class SpecialPoint:
    def __init__(self, point):
        self.point = point
        self.cartesian_point = None
    def plot(self, v1, v2, color, translation):
        if self.cartesian_point == None:
            self.cartesian_point = vector(self.point) * matrix((v1, v2))
        return point(self.cartesian_point + vector(translation), color =color, size = 20, zorder=2)
    def __eq__(self, other):
        return self.point == other.point
    def __hash__(self):
        return hash(self.point)
    def get_point(self):
        return self.point
    def set_growth_function(self, tes, symmetric_frame):
        self.growth_f = tes.get_growth_polynomials_parallelogram(1,1,self.get_point(), symmetric_frame)
    def set_charactetristic(self, tes, symmetric_frame):
        x0 = self.point
        if symmetric_frame:
            args = ((1,1), (2,2), (3,3))
        else:
            args = ((1,1), (1,2), (2,1), (2,2))
        self.characteristic = tuple( tuple(get_k_cells_num_parallelogram(arg[0], arg[1], get_k_cells(tes, i), tes.v1, tes.v2, i, x0, 1, 1, tes.v1, tes.v2)   for arg in args)     for i in range(3))
    def get_charactetristic(self):
        return self.characteristic
    def describe(self, v1, v2):
        print("Point ", self.point)


def calculate_mantisse(x):
    return x - floor(x) 

# I only need to consider changes in points. Cell changes frames iff one f its points changes frame


def find_rectangle_for_point(tes, point):
    min_mantisse_v1 = 1
    max_mantisse_v1 = 0
    min_mantisse_v2 = 1
    max_mantisse_v2 = 0
    for p in tes:
        new_p = subtract_vectors(p, point)
        m_v1 = calculate_mantisse(new_p[0])
        #print(m_v1, new_p)
        if m_v1 > max_mantisse_v1:
            max_mantisse_v1 = m_v1
        if m_v1 < min_mantisse_v1:
            min_mantisse_v1 = m_v1
        m_v2 = calculate_mantisse(new_p[1])
        if m_v2 > max_mantisse_v2:
            max_mantisse_v2 = m_v2
        if m_v2 < min_mantisse_v2:
            min_mantisse_v2 = m_v2
    # This if statement is very unlikely
    #print("Mantisses", min_mantisse_v1, " ", max_mantisse_v1, " ", min_mantisse_v2, " ", max_mantisse_v2)
    if min_mantisse_v1 == 1 or min_mantisse_v2 == 1:
        return None
    min_v1 = max(max_mantisse_v1 - 1 + point[0], 0)
    max_v1 = min(point[0] + min_mantisse_v1, 1)
    min_v2 = max(max_mantisse_v2 - 1 + point[1], 0)
    max_v2 = min(point[1] + min_mantisse_v2, 1)
    #print(min_v1, min_v2, max_v1, max_v2)
    return OpenRectangle((min_v1, min_v2), (max_v1, max_v2))


def find_domains(tessellation, symmetric_frame=True, full_plot=False):
    points = tessellation.polygon.points
    found_rectangles = []
    tes = set()
    for k in range(-1, 4):
        for l in range(-1, 4):
            add_cells(tes, points, multiply_by_scalar_and_add([(1,0), (0,1)], [k, l]), translate_vector)
    find_polynomials_in_complicated_domains(tes, OpenRectangle((0,0), (1,1)), found_rectangles, 1)
    #print("Found domains number", len(found_rectangles))
    different_types = set()
    polynomials = set()
    for rec in found_rectangles:
        rec.set_charactetristic(tessellation, symmetric_frame)
        polynomials.add(rec.get_charactetristic())
    colors = rainbow(len(polynomials))
    d = dict(zip(polynomials, colors))
        #print(rec.get_random_point()).translate
    max_x = max(tessellation.polygon.points, key = lambda p: p[0])[0]
    min_x = min(tessellation.polygon.points, key = lambda p: p[0])[0]
    min_y = min(tessellation.polygon.points, key = lambda p: p[1])[1]
    max_y = max(tessellation.polygon.points, key = lambda p: p[1])[1]
    G = Graphics()
    for k in range(floor(min_x), ceil(max_x)):
        for l in range(floor(min_y), ceil(max_y)):
            G = G +  sum(rect.to_graphic_polygon(tessellation.cartesian_vectors[0], tessellation.cartesian_vectors[1], d[rect.get_charactetristic()],
                                                                multiply_by_scalar_and_add(tessellation.cartesian_vectors, (k,l)) ) for rect in found_rectangles)
    if full_plot:
        edges_of_regions = set()
        points_set = set()
        lines_set = set()
        for rect in found_rectangles:
            for edge in rect.get_edges():
                points_set.add(SpecialPoint(edge[0]))
                points_set.add(SpecialPoint(edge[1]))
                lines_set.add(OpenLine(edge[0], edge[1]))
        G_lines = Graphics()
        G_points = Graphics()
        polynomials_lines_points = set()
        for l in lines_set:
            l.set_charactetristic(tessellation, symmetric_frame)
            polynomials_lines_points.add(l.get_charactetristic())
        for p in points_set:
            p.set_charactetristic(tessellation, symmetric_frame)
            polynomials_lines_points.add(p.get_charactetristic())
        d2 = dict(zip(polynomials_lines_points, rainbow(len(polynomials_lines_points))))
        for k in range(floor(min_x), ceil(max_x)):
            for l in range(floor(min_y), ceil(max_y)):
                G_lines = G_lines +  sum(line.plot(tessellation.cartesian_vectors[0], tessellation.cartesian_vectors[1], d2[line.get_charactetristic()],
                                                                multiply_by_scalar_and_add(tessellation.cartesian_vectors, (k,l)) ) for line in lines_set)
                G_points = G_points +  sum(p.plot(tessellation.cartesian_vectors[0], tessellation.cartesian_vectors[1], d2[p.get_charactetristic()],
                                                                multiply_by_scalar_and_add(tessellation.cartesian_vectors, (k,l)) ) for p in points_set)
        for poly in polynomials_lines_points:
            polynomials.add(poly)
    description_dic = dict( (polys, []) for polys in polynomials )
    for rect in found_rectangles:
        description_dic[rect.get_charactetristic()].append(rect)
    if full_plot:
        for l in lines_set:
            description_dic[l.get_charactetristic()].append(l)
        for p in points_set:
            description_dic[p.get_charactetristic()].append(p)
        return (G, G_lines, G_points,  description_dic)
    return (G,  description_dic)

def find_polynomials_in_complicated_domains(tessellation, domain, found_rectangles, area_to_fill):
    while area_to_fill > 0:
        p = domain.get_random_point()
        #p = (1/4, 1/4)
        if all(not o_rectangle.contains_ponts(p) for o_rectangle in found_rectangles):# Maybe I should use closed rectangles
            new_rectangle = find_rectangle_for_point(tessellation, p)
            if new_rectangle != None:
                area_to_fill = area_to_fill - new_rectangle.get_area()
                #print(new_rectangle.lower_left_corner, new_rectangle.higher_right_corner)
                #print("Area to fill", area_to_fill)
                found_rectangles.append(new_rectangle)
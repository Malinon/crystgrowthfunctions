from crystgrowthpoly.private import *
import re
import math
import numpy as np
from sage.all import *

"""
Function calculating number of 0 cells

@param n Number of translations in v1 direction
@param m Number of translations in v1 direction
@param points List of 0-cells
@param v1  Translation vector
@param v2  Translation vector

@return Number of 0 cells in tesselation
"""
def get_0_cells_num(n,m, points, v1, v2):
    points_in_tesselation = set()
    for i in range(n):
        for j in range(m):
            # Translate figure by v1*i + v2*j, add its points to points' set
            add_cells(points_in_tesselation, points, multiply_by_scalar_and_add([v1, v2], [i, j]), translate_vector)
    return len(points_in_tesselation)

def get_k_cells_num_parallelogram(n,m, cells, v1, v2, k, x0, scale_v1, scale_v2, frame_v1, frame_v2):
    cells_in_tesselation = set()
    if k == 0:
        # Count 0 cells
        censor = gen_is_point_in_parallelogram(n, m, frame_v1, frame_v2, x0)
        move_operator = translate_vector
    else:
        # Count 1 or 2 cells
        censor = gen_is_face_in_parallelogram(n, m,  frame_v1, frame_v2, x0)
        move_operator = translate_face
    for i in range(-1 , (n+2) * scale_v1):
        for j in range(-1 , (m+2) * scale_v2):
            add_cells_censored(cells_in_tesselation, cells, multiply_by_scalar_and_add([v1, v2], [i, j]), move_operator, censor)
    return len(cells_in_tesselation)

"""
Function finding growth polynomials

@param points 0-cells of repeating figure
@param num_of_2_cells Number of 2-cells in repeating figure
@param v1  tesselation vector
@param v2  tesselation vector
"""
def get_growth_polynomials_2d(points, num_of_2_cells, v1, v2):
    # Generate function calculating number of c-cells in given step of tesselation
    gen_val = lambda arg: get_0_cells_num(arg[0], arg[1], points, v1, v2)
    args = [(1,1), (1,2), (2,1), (2,2)]
    polynomial_0_cells =dim2_converter(find_poly(gen_val, args)[0])
    var("x1, x2, y1, y2")
    polynomial_2_cells = (x1+x2)*(y1+y2) * num_of_2_cells
    polynomial_1_cells = polynomial_0_cells + polynomial_2_cells - 1
    return (polynomial_0_cells, polynomial_1_cells, polynomial_2_cells)


"""
Function finding growth polynomials

@param points 0-cells of repeating figure
@param edges 1-cells of repeating figure
@param faces 2-cells of r
@param v1  tesselation vector
@param v2  tesselation vector
@param x0  
@param frame_scale_v1  frame_scale_v1 * v1 is used to define parallelogram frame
@param frame_scale_v2  frame_scale_v2 * v2 is used to define parallelogram frame
"""
def get_growth_polynomials_parallelogram(points, edges, faces, v1, v2, x0, frame_scale_v1 = 1, frame_scale_v2 = 1):
    args = [(1,1), (1,2), (2,1), (2,2)]
    if frame_scale_v1 != 1 or frame_scale_v2 != 1:

    # Find point equivalent to x0 near provided figure
    params = column_matrix([v1, v2]).solve_right(vector(subtract_vectors(points[0], x0)))
    x0_equivalent = translate_vector(translate_vector(x0, multiply_vector(v1, floor(params[0]))),  multiply_vector(v2, floor(params[1])))
    # Create functions calculating number of k-cell in given step of tesselation
    ##
    v1_frame = multiply_vector(v1, frame_scale_v1)
    v2_frame = multiply_vector(v2, frame_scale_v2)
    gen_num_of_0_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], points, v1, v2, 0, x0_equivalent, ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
    gen_num_of_1_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], edges, v1, v2, 1, x0_equivalent, ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
    gen_num_of_2_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], faces, v1, v2, 2, x0_equivalent,ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
    # Find growth polynomials
    polynomial_0_cells = dim2_converter(find_poly(gen_num_of_0_cells, args)[0])
    polynomial_1_cells = dim2_converter(find_poly(gen_num_of_1_cells, args)[0])
    polynomial_2_cells = dim2_converter(find_poly(gen_num_of_2_cells, args)[0])
    return (polynomial_0_cells, polynomial_1_cells, polynomial_2_cells)

def changed_frame(points, edges, faces, v1, v2, x0, frame_scale_v1, frame_scale_v2):
    try:
        rational_scale_v1 = Rational(frame_scale_v1)
        rational_scale_v2 = Rational(frame_scale_v2)
    except TypeError:
        raise TypeError("Frame scale need to be rational number")
    N = lcm(rational_scale_v1.denominator(), rational_scale_v1.denominator())
    # Find point equivalent to x0 near provided figure
    params = column_matrix([v1, v2]).solve_right(vector(subtract_vectors(points[0], x0)))
    x0_equivalent = translate_vector(translate_vector(x0, multiply_vector(v1, floor(params[0]))),  multiply_vector(v2, floor(params[1])))
    for s in range(N):
        args = tuple(tuple(arg[0]* N + s, arg[0]* N + s) for arg in ((1,1), (1,2), (2,1), (2,2)) ) # temporary arguments
        v1_frame = multiply_vector(v1, frame_scale_v1)
        v2_frame = multiply_vector(v2, frame_scale_v2)
        gen_num_of_0_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], points, v1, v2, 0, x0_equivalent, ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
        gen_num_of_1_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], edges, v1, v2, 1, x0_equivalent, ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
        gen_num_of_2_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], faces, v1, v2, 2, x0_equivalent,ceil(frame_scale_v1), ceil(frame_scale_v2), v1_frame, v2_frame)
        # Find growth polynomials
        polynomial_0_cells = dim2_converter(find_poly(gen_num_of_0_cells, args)[0])
        polynomial_1_cells = dim2_converter(find_poly(gen_num_of_1_cells, args)[0])
        polynomial_2_cells = dim2_converter(find_poly(gen_num_of_2_cells, args)[0])
    return (polynomial_0_cells, polynomial_1_cells, polynomial_2_cells)


"""
Pretty print of growth polynomials
"""
def print_2_variables(polynomials):
    var("f_0, f_1, f_2, x1, x2, y1, y2, k, l")
    pretty_print(f_0,(k,l), "=", polynomials[0].subs({x1:k, y1:l, x2:0, y2:0}))
    pretty_print(f_1,(k,l), "=", polynomials[1].subs({x1:k, y1:l, x2:0, y2:0}))
    pretty_print(f_2,(k,l), "=", polynomials[2].subs({x1:k, y1:l, x2:0, y2:0}))

class Polygon:
    def __init__(self,points, edges, faces):
        self.points = points
        self.edges = [sort_points_in_cell(edge) for edge in edges]
        self.faces = [sort_points_in_cell(face) for face in faces]
        self.faces_raw = faces # [sort_points_in_cell(face) for face in faces] # Positive oriented figures are needed for triangulation


class Tesselation:
    def __init__(self, polygon, v1, v2):
        self.polygon = polygon
        self.v1 = v1
        self.v2 = v2
    def get_growth_polynomials_parallelogram(self, scale_v1 = 1, scale_v2 = 1, x0 = (0,0)):
        return get_growth_polynomials_parallelogram(self.polygon.points, self.polygon.edges, self.polygon.faces, self.v1, self.v2, x0, frame_scale_v1 = scale_v1, frame_scale_v2 = scale_v2)
    def get_growth_polynomials(self):
        return get_growth_polynomials_2d(self.polygon.points, len(self.polygon.faces), self.v1, self.v2)
    def get_crystalographic_coordinates(self, point):
        inv_mat = ~column_matrix([self.v1, self.v2])
        coords = inv_mat * column_matrix(point)
        return (coords[0][0], coords[1][0])

    def get_characterisation(point, tesselation, checker):
        num_of_cells_table = np.zeros((5,len(tesselation)))
        #zero_a = []
        for i in range(len(tesselation)):
            for p in tesselation[i]:
                # Calculations for points
                coord = checker(p, point)
                if coord >= 0:
                    n_min = ceil(coord)
                    if n_min < 6:
                        num_of_cells_table[n_min-1, i] = num_of_cells_table[n_min -1, i] + 1
                    #if n_min == 1:
                    #    zero_a.append(p)
        #print(zero_a)
        return hash(num_of_cells_table.data.tobytes())
    def generate_points_along_the_edges(self, number_of_points):
        starts = []
        ends = []
        for e in self.polygon.edges:
            starts.append(e[0])
            ends.append(e[1])
        return Tesselation.generate_points_along_the_lines(starts, ends, number_of_points)
    def generate_points_along_the_lines(starts_of_the_lines, ends_of_the_lines, number_of_points):
        points = []
        for i in range(len(starts_of_the_lines)):
            direction_vec = subtract_vectors(ends_of_the_lines[i], starts_of_the_lines[i])
            for j in range(0, number_of_points + 1):
                p = (j/number_of_points)
                points.append(translate_vector(starts_of_the_lines[i], multiply_vector(direction_vec, SR(p)) ))
            points.append(ends_of_the_lines[i])
        return points
    def plot_sections_along_the_lines(self, starts_of_the_lines, ends_of_the_lines, number_of_points):
        return self.plot_polynomial_types_for_points(Tesselation.generate_points_along_the_lines(starts_of_the_lines, ends_of_the_lines, number_of_points))
    def plot_sections_along_the_edges(self, n):
        starts = []
        ends = []
        for e in self.polygon.edges:
            starts.append(e[0])
            ends.append(e[1])
        return self.plot_sections_along_the_lines(starts, ends, 20)
        
    def plot_polynomial_types_for_points(self, random_points, full_check = False):
        inv_mat = ~column_matrix([self.v1, self.v2])
        def get__max_coordinates(edge, x0):
            coords = tuple(subtract_vectors(p, x0) for p in edge)
            if any( any( p<0 for p in coord) for coord in coords):
                # This edge is not inside any considered parallelogram for sure 
                return -1
            else:
                if (len(coords)) ==0:
                    print("errror, zero")
                return max( max(p) for p in coords)
        test_tesselation = set()
        crystal_edges = [(self.get_crystalographic_coordinates(e[0]), self.get_crystalographic_coordinates(e[1]))   for e in self.polygon.edges] # TODO: add checking if already crystalographic
        for i in range(-1,6):
            for j in range(-1,6):
                add_cells(test_tesselation, crystal_edges, multiply_by_scalar_and_add([(1,0), (0,1)], [i, j]), translate_face)
        if full_check:
            crystal_points = [ (self.get_crystalographic_coordinates(p),) for p in self.polygon.points]
            crystal_faces =  [ tuple(self.get_crystalographic_coordinates(p) for p in f) for f in self.polygon.faces]
            test_tesselation_points = set()
            test_tesselation_faces = set()
            for i in range(-1,6):
                for j in range(-1,6):
                    add_cells(test_tesselation_faces, crystal_faces, multiply_by_scalar_and_add([(1,0), (0,1)], [i, j]), translate_face)
                    add_cells(test_tesselation_points, crystal_points, multiply_by_scalar_and_add([(1,0), (0,1)], [i, j]), translate_face)
            tessellations = [test_tesselation_faces, test_tesselation]
        else:
            tessellations = [test_tesselation]
        distinct_hashes = set()
        characteristics = []
        for p in random_points:
            new_hash = Tesselation.get_characterisation(self.get_crystalographic_coordinates(p), tessellations, get__max_coordinates)
            distinct_hashes.add(new_hash)
            characteristics.append(new_hash)
        colors = rainbow(len(distinct_hashes))
        color_mapping = {}
        iterator = 0
        print(len(distinct_hashes))
        for h in distinct_hashes:
            color_mapping[h] = colors[iterator]
            iterator = iterator + 1
        return sum( point((random_points[i][0],random_points[i][1]), color=Color(color_mapping[characteristics[i]])) for i in range(len(characteristics)))
    def plot_sections(self, num_of_points, plot_edges = False, n_edges = 20, additional_lines=None, n_lines=20, full_check = False):
        triangles = []
        for face in self.polygon.faces_raw:
            Triangle.add_triangulation(face, triangles)
        field_of_polygon = sum( triangle.area for triangle in triangles)
        if plot_edges:
            random_points = self.generate_points_along_the_edges(n_edges)
        else:
            random_points = []
        if additional_lines != None:
            random_points.extend(Tesselation.generate_points_along_the_lines(additional_lines[0], additional_lines[1], n_lines))
        for triangle in triangles:
            triangle.add_random_points(random_points, field_of_polygon, num_of_points)
        return self.plot_polynomial_types_for_points(random_points, full_check)

def read_tesselation_from_file_real(file_path):
    input_file = open(file_path, 'r')
    lines = input_file.readlines()
    cells_nums = [int(s) for s in re.findall(r"\d+", lines[0])]
    points = [string_to_point(lines[i]) for i in range(1, cells_nums[0] + 1)]
    edges = [string_to_cell(lines[i], points) for i in range(1+cells_nums[0], cells_nums[0] + cells_nums[1] + 1)]
    faces = [string_to_cell(lines[i], points) for i in range(1+cells_nums[0] + cells_nums[1], cells_nums[0] + cells_nums[1] + cells_nums[2] + 1)]
    v1 = string_to_point(lines[ cells_nums[0] + cells_nums[1] + cells_nums[2] + 1])
    v2 = string_to_point(lines[ cells_nums[0] + cells_nums[1] + cells_nums[2] + 2])
    return Tesselation(Polygon(points, edges, faces), v1, v2)

def read_tesselation_from_file(file_path, crystalographic_coordinates=True):
    input_file = open(file_path, 'r')
    lines = input_file.readlines()
    cells_nums = [int(s) for s in re.findall(r"\d+", lines[0])]
    if crystalographic_coordinates:
        points = [string_to_point(lines[i]) for i in range(1, cells_nums[0] + 1)]
        v1 = (1, 0)
        v2 = (0, 1)
    else:
        v1 = string_to_point(lines[ cells_nums[0] + cells_nums[1] + cells_nums[2] + 1])
        v2 = string_to_point(lines[ cells_nums[0] + cells_nums[1] + cells_nums[2] + 2])
        points = [multiply_by_scalar_and_add([v1, v2], string_to_point(lines[i])) for i in range(1, cells_nums[0] + 1)]
    edges = [string_to_cell(lines[i], points) for i in range(1+cells_nums[0], cells_nums[0] + cells_nums[1] + 1)]
    faces = [string_to_cell(lines[i], points) for i in range(1+cells_nums[0] + cells_nums[1], cells_nums[0] + cells_nums[1] + cells_nums[2] + 1)]
    return Tesselation(Polygon(points, edges, faces), v1, v2)

def get_generators_for_tests(points, edges, faces, v1, v2, x0):
    gen_num_of_0_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], points, v1, v2, 0, x0, 1, 1, v1, v2)
    gen_num_of_1_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], edges, v1, v2, 1, x0, 1, 1, v1, v2)
    gen_num_of_2_cells = lambda arg: get_k_cells_num_parallelogram(arg[0], arg[1], faces, v1, v2, 2, x0, 1, 1, v1, v2)
    return [gen_num_of_0_cells, gen_num_of_1_cells, gen_num_of_2_cells]

def get_val(x_val_1, x_val_2, y_val_1, y_val_2, poly):
    return poly.subs({x1:x_val_1, x2: x_val_2, y1:y_val_1, y2:y_val_2})


def test_polynomials_for_parallelogram(polynomials, points, edges, faces, v1, v2, x0):
    values_generators = get_generators_for_tests(points, edges, faces, v1, v2, x0)
    arguments = [(i,j) for i in range(1,11) for j in  range(1,11)]
    for i in range(3):
        for arg in arguments:
            val_pol = get_val(arg[0], 0, arg[1], 0, polynomials[i])
            val_real = values_generators[i](arg)
            if val_pol != val_real:
                print("Wrong value! ", "Polynomial value ", val_pol, " Real value ", val_real, "parameters ", i, " ", arg)